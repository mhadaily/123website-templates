
        ////////////////////////////////////
        // animate.js
        document.write('<link href="animate.min.css" rel="stylesheet">');
        ////////////////////////////////////
    