Here is [a single page template perfect to announce an event or a special offer](http://silex-templates.silex.me/tech-tools/). It is made with [Silex](http://www.silex.me/), and it is hosted for free on github.

[![screenshot-800x600](http://silex-templates.silex.me/tech-tools/screenshot-678x336.png)](http://silex-templates.silex.me/tech-tools/)

