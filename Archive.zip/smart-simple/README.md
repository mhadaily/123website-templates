Here is a template advertising a fictional mobile app or online service. This is an HTML template to edit with [Silex website editor](http://www.silex.me), the open source website builder(free and open source).

It is made with <a href="http://www.silex.me">Silex</a>, and can be hosted anywhere. It is responsive to fit any screen size with the maximum reach.

[![screenshot](http://silex-templates.silex.me/smart-simple/screenshot.png)](http://silex-templates.silex.me/smart-simple/)
