Here is [a 4 pages template, perfect for eco-aware projects](http://silex-templates.silex.me/eco1/). It is made with [Silex](http://www.silex.me/), and it is hosted for free on github.

[![screenshot-800x600](http://silex-templates.silex.me/eco1/screenshot-678x336.png)](http://silex-templates.silex.me/eco1/)
